package com.ecom.Utility;

public class AppConstant {

    public static final int ATTEMPT_TIME=3;
    public static final long UNLOCK_TIME=60*60*1000;
}
